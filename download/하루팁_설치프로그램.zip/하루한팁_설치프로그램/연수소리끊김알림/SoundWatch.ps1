﻿# 소리 끊김 알림: 화면 오른쪽 아래에 항상 맨 위 상태창을 띄우고,
# 스피커 출력이 10초 이상 없으면 빨간 경고로 바꾼다.
param(
    [int]$SilenceSec = 10,        # 몇 초 무음이면 알림
    [double]$Threshold = 0.0005,  # 이 값보다 작으면 무음으로 본다 (0~1)
    [int]$IntervalMs = 250        # 검사 주기
)
$LogPath = Join-Path $PSScriptRoot 'log.txt'
function Write-Log($msg) { try { Add-Content -Path $LogPath -Value ("{0:HH:mm:ss} {1}" -f (Get-Date), $msg) -Encoding UTF8 } catch {} }

Add-Type -AssemblyName System.Windows.Forms, System.Drawing

$created = $false
$mutex = New-Object System.Threading.Mutex($true, 'Local\SoundWatch_Alert', [ref]$created)
if (-not $created) {
    [System.Windows.Forms.MessageBox]::Show("이미 켜져 있습니다.`n화면 오른쪽 아래 상태창을 확인하세요.", '소리 끊김 알림') | Out-Null
    exit
}

Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;

[ComImport, Guid("BCDE0395-E52F-467C-8E3D-C4579291692E")]
class MMDeviceEnumeratorCom {}

[Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface IMMDeviceEnumerator {
    int EnumAudioEndpoints(int dataFlow, int stateMask, out IntPtr devices);
    int GetDefaultAudioEndpoint(int dataFlow, int role, out IMMDevice device);
}

[Guid("D666063F-1587-4E43-81F1-B948E807363F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface IMMDevice {
    int Activate(ref Guid iid, int clsCtx, IntPtr activationParams, [MarshalAs(UnmanagedType.IUnknown)] out object iface);
}

[Guid("C02216F6-8C67-4B5B-9D00-D008E73E0064"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface IAudioMeterInformation {
    int GetPeakValue(out float peak);
}

public static class SoundWatchPeak {
    // 기본 출력 장치의 현재 음량 피크(0~1). 장치가 없으면 -1.
    public static float Get() {
        object en = null, meter = null; IMMDevice dev = null;
        try {
            en = new MMDeviceEnumeratorCom();
            if (((IMMDeviceEnumerator)en).GetDefaultAudioEndpoint(0, 1, out dev) != 0 || dev == null) return -1;
            Guid iid = typeof(IAudioMeterInformation).GUID;
            if (dev.Activate(ref iid, 23, IntPtr.Zero, out meter) != 0 || meter == null) return -1;
            float p;
            if (((IAudioMeterInformation)meter).GetPeakValue(out p) != 0) return -1;
            return p;
        } catch { return -1; }
        finally {
            if (meter != null) Marshal.ReleaseComObject(meter);
            if (dev != null) Marshal.ReleaseComObject(dev);
            if (en != null) Marshal.ReleaseComObject(en);
        }
    }
}

public static class SoundWatchWin {
    [DllImport("user32.dll")] static extern bool SetWindowPos(IntPtr h, IntPtr after, int x, int y, int cx, int cy, uint flags);
    [DllImport("user32.dll")] static extern bool ReleaseCapture();
    [DllImport("user32.dll")] static extern IntPtr SendMessage(IntPtr h, int msg, IntPtr w, IntPtr l);
    // 포커스를 뺏지 않고 모든 창 위로 올린다 (HWND_TOPMOST, NOMOVE|NOSIZE|NOACTIVATE|SHOWWINDOW)
    public static void Top(IntPtr h) { SetWindowPos(h, new IntPtr(-1), 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0010 | 0x0040); }
    // 창 아무 곳이나 끌어서 옮기기
    public static void Drag(IntPtr h) { ReleaseCapture(); SendMessage(h, 0xA1, new IntPtr(2), IntPtr.Zero); }
}
'@

$script:lastSound = Get-Date
$script:alerted   = $false
$script:alertAt   = Get-Date
$script:paused    = $false
$script:moved     = $false

$C = @{
    ok    = [System.Drawing.Color]::FromArgb(22, 101, 52)
    warn  = [System.Drawing.Color]::FromArgb(180, 83, 9)
    red   = [System.Drawing.Color]::FromArgb(220, 38, 38)
    yel   = [System.Drawing.Color]::FromArgb(250, 204, 21)
    gray  = [System.Drawing.Color]::FromArgb(82, 82, 91)
    white = [System.Drawing.Color]::White
    black = [System.Drawing.Color]::Black
}
$SmallSize = New-Object System.Drawing.Size(420, 110)
$BigSize   = New-Object System.Drawing.Size(640, 270)

# ── 상태창 ──
$win = New-Object System.Windows.Forms.Form
$win.FormBorderStyle = 'None'
$win.ShowInTaskbar = $false
$win.TopMost = $true
$win.StartPosition = 'Manual'
$win.Size = $SmallSize
$win.BackColor = $C.ok
$win.Opacity = 0.95

$title = New-Object System.Windows.Forms.Label
$title.Font = New-Object System.Drawing.Font('맑은 고딕', 22, [System.Drawing.FontStyle]::Bold)
$title.ForeColor = $C.white
$title.AutoSize = $false
$title.TextAlign = 'MiddleLeft'
$win.Controls.Add($title)

$sub = New-Object System.Windows.Forms.Label
$sub.Font = New-Object System.Drawing.Font('맑은 고딕', 12)
$sub.ForeColor = $C.white
$sub.AutoSize = $false
$sub.TextAlign = 'MiddleLeft'
$win.Controls.Add($sub)

$okBtn = New-Object System.Windows.Forms.Button
$okBtn.Text = '확인'
$okBtn.Font = New-Object System.Drawing.Font('맑은 고딕', 14, [System.Drawing.FontStyle]::Bold)
$okBtn.BackColor = $C.white
$okBtn.ForeColor = $C.black
$okBtn.FlatStyle = 'Flat'
$okBtn.Visible = $false
$win.Controls.Add($okBtn)

function Set-Layout($big) {
    $win.Size = if ($big) { $BigSize } else { $SmallSize }
    $w = $win.Width; $h = $win.Height
    if ($big) {
        $title.Font = New-Object System.Drawing.Font('맑은 고딕', 34, [System.Drawing.FontStyle]::Bold)
        $title.SetBounds(24, 20, $w - 48, 90)
        $sub.Font = New-Object System.Drawing.Font('맑은 고딕', 18, [System.Drawing.FontStyle]::Bold)
        $sub.SetBounds(24, 112, $w - 48, 80)
        $okBtn.SetBounds($w - 164, $h - 70, 140, 50)
        $okBtn.Visible = $true
    } else {
        $title.Font = New-Object System.Drawing.Font('맑은 고딕', 22, [System.Drawing.FontStyle]::Bold)
        $title.SetBounds(18, 8, $w - 36, 54)
        $sub.Font = New-Object System.Drawing.Font('맑은 고딕', 12)
        $sub.SetBounds(20, 62, $w - 40, 36)
        $okBtn.Visible = $false
    }
    if (-not $script:moved) {
        $area = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea
        $win.Location = New-Object System.Drawing.Point(($area.Right - $w - 12), ($area.Bottom - $h - 12))
    } else {
        # 사용자가 옮긴 위치를 기준으로 오른쪽 아래 모서리를 고정
        $win.Location = New-Object System.Drawing.Point(($script:anchorR - $w), ($script:anchorB - $h))
    }
}

# 끌어서 옮기기 (창·글자 어디를 잡아도)
$dragHandler = {
    param($s, $e)
    if ($e.Button -eq 'Left') {
        [SoundWatchWin]::Drag($win.Handle)
        $script:moved = $true
        $script:anchorR = $win.Right; $script:anchorB = $win.Bottom
    }
}
$win.Add_MouseDown($dragHandler); $title.Add_MouseDown($dragHandler); $sub.Add_MouseDown($dragHandler)

function Clear-Alert {
    $script:alerted = $false
    $blinkTimer.Stop()
    Set-Layout $false
}
$okBtn.Add_Click({ $script:lastSound = Get-Date; Clear-Alert })
$win.Add_FormClosing({ param($s, $e) if (-not $script:quitting) { $e.Cancel = $true } })

# 깜빡임: 빨강↔노랑 (경고가 떠 있는 동안 계속)
$script:blink = 0
$blinkTimer = New-Object System.Windows.Forms.Timer
$blinkTimer.Interval = 400
$blinkTimer.Add_Tick({
    $script:blink++
    if ($script:blink % 2) { $win.BackColor = $C.yel; $title.ForeColor = $C.black; $sub.ForeColor = $C.black }
    else { $win.BackColor = $C.red; $title.ForeColor = $C.white; $sub.ForeColor = $C.white }
})

function Show-Alert {
    $script:alerted = $true
    $script:alertAt = Get-Date
    Set-Layout $true
    $title.Text = '소리 끊김!'
    $sub.Text = "${SilenceSec}초 넘게 소리가 없어요`n연수 다음으로 넘어가세요"
    $script:blink = 0; $blinkTimer.Start()
    [SoundWatchWin]::Top($win.Handle)
    [System.Media.SystemSounds]::Exclamation.Play()
    Write-Log 'ALERT'
}

# ── 트레이 아이콘 (멈춤·종료) ──
$notify = New-Object System.Windows.Forms.NotifyIcon
$notify.Icon = [System.Drawing.SystemIcons]::Information
$notify.Text = '소리 끊김 알림'
$notify.Visible = $true
$menu = New-Object System.Windows.Forms.ContextMenuStrip
$pauseItem = $menu.Items.Add('잠시 멈춤')
$exitItem  = $menu.Items.Add('종료')
$notify.ContextMenuStrip = $menu
$win.ContextMenuStrip = $menu
$pauseItem.Add_Click({
    $script:paused = -not $script:paused
    $pauseItem.Text = if ($script:paused) { '다시 감시' } else { '잠시 멈춤' }
    $script:lastSound = Get-Date
    Clear-Alert
})

# ── 감시 루프 ──
$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = $IntervalMs
$timer.Add_Tick({
    try {
        [SoundWatchWin]::Top($win.Handle)   # 다른 창이 올라와도 계속 맨 위
        if ($script:paused) {
            $win.BackColor = $C.gray; $title.ForeColor = $C.white; $sub.ForeColor = $C.white
            $title.Text = '감시 멈춤'
            $sub.Text = '우클릭 → 다시 감시'
            return
        }
        $peak = [SoundWatchPeak]::Get()
        $now = Get-Date
        if ($peak -gt $Threshold) {
            # 알림음 자체가 소리로 잡히지 않게 알림 직후 3초는 무시
            if ($script:alerted -and ($now - $script:alertAt).TotalSeconds -lt 3) { return }
            $script:lastSound = $now
            if ($script:alerted) { Clear-Alert }
        }
        if ($script:alerted) { return }
        $quiet = ($now - $script:lastSound).TotalSeconds
        if ($peak -lt 0) {
            $win.BackColor = $C.gray
            $title.Text = '스피커 없음'
            $sub.Text = '출력 장치를 확인하세요'
        } elseif ($quiet -ge $SilenceSec) {
            Show-Alert
        } elseif ($quiet -ge 1) {
            $win.BackColor = $C.warn; $title.ForeColor = $C.white; $sub.ForeColor = $C.white
            $title.Text = ('무음 {0}초 / {1}초' -f [int][math]::Floor($quiet), $SilenceSec)
            $sub.Text = '조금 더 조용하면 경고가 떠요'
        } else {
            $win.BackColor = $C.ok; $title.ForeColor = $C.white; $sub.ForeColor = $C.white
            $title.Text = '소리 나는 중'
            $sub.Text = '연수 감시 중 · 끄기: 우클릭 → 종료'
        }
    } catch { Write-Log "ERROR $_" }
})

$exitItem.Add_Click({
    $script:quitting = $true
    $timer.Stop(); $blinkTimer.Stop()
    $notify.Visible = $false
    $notify.Dispose()
    $win.Close()
    [System.Windows.Forms.Application]::Exit()
})

Set-Layout $false
$title.Text = '감시 시작'
$sub.Text = '연수 감시 중 · 끄기: 우클릭 → 종료'
$win.Show()
[SoundWatchWin]::Top($win.Handle)
$timer.Start()
Write-Log 'START'
[System.Windows.Forms.Application]::Run()
$mutex.ReleaseMutex()
